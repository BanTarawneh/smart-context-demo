SMART CONTEXT WEBSITE

This folder contains the production-built static website.

To preview locally:
1. Open a terminal in this folder.
2. Run a static file server, for example: npx serve .
3. Open the address shown by the server.

To host online, upload all files in this folder to any static website host.
Keep index.html, assets/, and brand/ together.
